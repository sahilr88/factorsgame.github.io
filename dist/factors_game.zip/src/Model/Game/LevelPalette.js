function LevelPalette (numberColor, boardColors, backgroundColor) {
  this.numberColor = numberColor;
  this.boardColors = boardColors;
  this.backgroundColor = backgroundColor;
}
