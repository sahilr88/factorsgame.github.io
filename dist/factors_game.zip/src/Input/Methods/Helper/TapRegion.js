function TapRegion (boundingBox, onTap) {
  this.boundingBox = boundingBox;
  this.onTap = onTap;
}
